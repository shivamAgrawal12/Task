'use strict';
jQuery(function( $ ){
    $.fn.formToJson = function( resultContainer ){
          const form = this;
        let submittedData = [];
        let formData = {
            id : Number ,
            fullname : String ,
            dob : Date ,
            email : String ,
            password : String ,
            zipcode : Number ,
            address : String ,
            createdDate : String
        };
        let jsonOutputData = Object.create(formData);

        $(form).submit(function( event ){
            event.preventDefault();

            sortData( $(form).serialize() );

            jsonData();
            outputData();
            resetData();

        });

        function sortData( data ){
            // sanity check
            if(data != undefined){
                const regxSpace = /(?:%20)/gi;
                const regxEmail = /(?:%40)/gi;
                const regxLineBreak = /(?:%0D%0A)/gi;
                let sortedData = data.replace(regxSpace, ' ').replace(regxEmail, '@').replace(regxLineBreak, '\n').split('&');
                $(sortedData).each(function(index, element){
                    submittedData.push(element.split('='));
                });
            }
        };

        function jsonData(){
            // sanity check
            if(submittedData != undefined || submittedData != null){
                // create JSON data
                $(submittedData).promise().done(function(){
                    // save json data
                    jsonOutputData.id = Math.random();
                    jsonOutputData.fullname = submittedData[0][1];
                    jsonOutputData.dob = submittedData[1][1];
                    jsonOutputData.email = submittedData[2][1];
                    jsonOutputData.password = submittedData[3][1];
                    jsonOutputData.zipcode = submittedData[4][1];
                    jsonOutputData.address = submittedData[5][1],
                    jsonOutputData.createdDate = Date.now()
                });
            }
        };

        function outputData(){
            let stringifyJsonData = JSON.stringify(jsonOutputData);

            if(resultContainer !== undefined || resultContainer !== null){
                $(jsonOutputData).promise().done(function(){
                    $(resultContainer).html( stringifyJsonData );
                    console.log(stringifyJsonData); 
                });
            }
            else{
                console.log('resultContainer undefined');
                return stringifyJsonData;
            }
        }

        function resetData(){
            submittedData = [];
            jsonOutputData = {};
        }
        
    }
}(jQuery));